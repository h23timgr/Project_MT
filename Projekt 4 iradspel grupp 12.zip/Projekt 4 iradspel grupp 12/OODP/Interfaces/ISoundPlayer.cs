namespace FourInARow
{
    public interface ISoundPlayer // Gr�nssnitt f�r ljuduppspelning
    {
        void PlayWinSound();
    }
}